<?php 
	require 'db.php';
?>
<?php
$host = 'localhost';
$dbname = 'ozimiz';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Ошибка подключения к базе данных: " . $e->getMessage());
}
?>
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Получение данных из формы
    $name = $_POST['name_c'];
    $description = $_POST['description'];
    $long = $_POST['long'];
    $tag = $_POST['tag'];

    // Подготовка SQL-запроса с использованием подстановки параметров
    $stmt = $pdo->prepare("INSERT INTO courses (name_c, description, `long`, tag) VALUES (?, ?, ?, ?)");

    // Привязка значений к параметрам и выполнение запроса
    $stmt->execute([$name, $description, $long, $tag]);

    // Опционально: проверка на успешное выполнение запроса
    if ($stmt->rowCount() > 0) {
        echo "Данные успешно добавлены в базу данных.";
    } else {
        echo "Произошла ошибка при добавлении данных.";
    }
}


?>

<?php 



?>
<?php if ( isset ($_SESSION['logged_user']) ) : ?>
    <!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ozimiz.kaz</title>
    <link rel="shortcut icon" href="assets/images/IMG_7797.PNG" type="image/x-icon">

    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/icofont.min.css">
    <link rel="stylesheet" href="assets/css/swiper.min.css">
    <link rel="stylesheet" href="assets/css/lightcase.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

    <!-- preloader start here -->
    <div class="preloader">
        <div class="preloader-inner">
            <div class="preloader-icon">
                <span></span>
                <span></span>
            </div>
        </div>
    </div>
    <!-- preloader ending here -->


    <!-- scrollToTop start here -->
    <a href="#" class="scrollToTop"><i class="icofont-rounded-up"></i></a>
    <!-- scrollToTop ending here -->


    <!-- header section start here -->
    <header class="header-section">
        <div class="header-bottom">
            <div class="container">
                <div class="header-wrapper">
                    <div class="logo">
                        <a href="#">
                            <img src="assets/images/logo.png"  alt="logo" width="200px">
                        </a>
                    </div>
                    <div class="menu-area">
                        <div class="menu">
                            <ul class="lab-ul">
                                <li>
                                    <a href="/ozimiz/home-admin.php">Главная</a>
                                </li>
                                
                                <li>
                                    <a href="/ozimiz/h-a-courses.php">Курсы</a>
                                </li>
                            </ul>
                        </div>
                        
                        <a href="#" class="login"><i class="icofont-user"></i> <span><?=$_SESSION['logged_user']->name?></span> </a>
                        <a href="/ozimiz/logout.php" class="signup"><i class="icofont-users"></i> <span>Выйти</span> </a>

                        <!-- toggle icons -->
                        <div class="header-bar d-lg-none">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <div class="ellepsis-bar d-lg-none">
                            <i class="icofont-info-square"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- header section ending here -->

    <div class="container" style="background-color: white;padding-top: 200px;padding-bottom: 200px;"> 
       
        <div class="section-header text-center">
            <span class="subtitle">Курсы </span>
            <h2 class="title">У вас пока нет курсов, создайте первый</h2>
        </div>
        <form method="post" action="" class="section-header text-center" enctype="multipart/form-data">
    <input name="name_c" type="text" placeholder="Название курса" style="width:70%;"><br><br>
    <textarea name="description" placeholder="Описание" class="form-control" id="exampleFormControlTextarea1" rows="3" style="width:70%;margin:0px auto;"></textarea><br>
    <input name="long" type="number" placeholder="Продолжительность" style="width:70%;"><br><br>
    <input name="tag" type="text" placeholder="Добавить ТЭГ курсу" style="width:70%;"><br><br>
    <button type="submit" class="btn-primary mt-5">Создать курс</button>
</form>
        <p class="desc section-header  text-center" style="margin:auto; font-size: 20px;line-height: 1.5; width:70%;">
Начните работу над черновиком курса, перед публикацией можно будет сделать курс платным или оставить бесплатным.

Открытые бесплатные курсы и уроки распространяются по лицензии Creative Commons (CC BY-SA 4.0).
       </p>
    </div>
    <!-- footer -->
    <div class="news-footer-wrap">
        
        <!-- Footer Section Start Here -->
        <footer>
            <div class="footer-bottom style-2">
                <div class="container">
                    <div class="section-wrapper">
                        <p>&copy; 2023 <a href="#">Ozimiz</a> Разработана командой<a href="#" target="_blank">Kandichioner</a> </p>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Footer Section Ending Here -->
    </div>
    <!-- footer -->


    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/swiper.min.js"></script>
    <script src="assets/js/progress.js"></script>
    <script src="assets/js/lightcase.js"></script>
    <script src="assets/js/counter-up.js"></script>
    <script src="assets/js/isotope.pkgd.js"></script>
    <script src="assets/js/functions.js"></script>

</body>
</html>

<?php else : ?>
    <? echo 'none';?>
<?php endif; ?>
