<?php 
	require 'db.php';

	$data = $_POST;
	if ( isset($data['do_login']) )
	{
		$user = R::findOne('users', 'email = ?', array($data['email']));
		if ( $user )
		{
			//логин существует
			if ( password_verify($data['password'], $user->password) )
			{
				//если пароль совпадает, то нужно авторизовать пользователя
				$_SESSION['logged_user'] = $user;
				header("Location: /ozimiz/home-admin.php");
			}else
			{
				$errors[] = 'Неверно введен пароль!';
			}

		}else
		{
			$errors[] = 'Пользователь с таким логином не найден!';
		}
		
		if ( ! empty($errors) )
		{
			//выводим ошибки авторизации
			echo '<div id="errors" style="color:red;">' .array_shift($errors). '</div><hr>';
		}

	}

?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ozimiz.kaz</title>
    <link rel="shortcut icon" href="assets/images/IMG_7797.PNG" type="image/x-icon">

    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/icofont.min.css">
    <link rel="stylesheet" href="assets/css/swiper.min.css">
    <link rel="stylesheet" href="assets/css/lightcase.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

    <!-- preloader start here -->
    <div class="preloader">
        <div class="preloader-inner">
            <div class="preloader-icon">
                <span></span>
                <span></span>
            </div>
        </div>
    </div>
    <!-- preloader ending here -->


    <!-- scrollToTop start here -->
    <a href="#" class="scrollToTop"><i class="icofont-rounded-up"></i></a>
    <!-- scrollToTop ending here -->


    <!-- header section start here -->
    <header class="header-section">
        <div class="header-top">
            <div class="container">
                <div class="header-top-area">
                    <ul class="lab-ul left">
                        <li>
                            <i class="icofont-ui-call"></i> <span>+700-123-4567 7292</span>
                        </li>
                        <li>
                            <i class="icofont-location-pin"></i> Актау, Казахстан
                        </li>
                    </ul>
                    <ul class="lab-ul social-icons d-flex align-items-center">
                        <li><p>Найдите нас на : </p></li>
                        <li><a href="#" class="twitter"><i class="icofont-youtube"></i></a></li>
                        <li><a href="#" class="vimeo"><i class="icofont-whatsapp"></i></a></li>
                        <li><a href="#" class="skype"><i class="icofont-instagram"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="header-bottom">
            <div class="container">
                <div class="header-wrapper">
                    <div class="logo">
                        <a href="/ozimiz/">
                            <img src="assets/images/logo.png"  alt="logo" width="200px">
                        </a>
                    </div>
                    <div class="menu-area">
                        <div class="menu">
                            <ul class="lab-ul">
                                <li>
                                    <a href="/ozimiz/">Главная</a>
                                </li>
                                
                                <li>
                                    <a href="#">Курсы</a>
                                    <ul class="lab-ul">
                                        <li><a href="#">Программирование</a></li>
                                        <li><a href="#">Курсы английского</a></li>
                                    </ul>
                                </li>
                                <li><a href="#">Контакты</a></li>
                            </ul>
                        </div>
                        
                        <a href="/ozimiz/login.php" class="login"><i class="icofont-user"></i> <span>Войти</span> </a>
                        <a href="/ozimiz/signup.php" class="signup"><i class="icofont-users"></i> <span>Зарегистрироватся</span> </a>

                        <!-- toggle icons -->
                        <div class="header-bar d-lg-none">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <div class="ellepsis-bar d-lg-none">
                            <i class="icofont-info-square"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- header section ending here -->


    

    <!-- Login Section Section Starts Here -->
    <div class="login-section padding-tb section-bg" style="padding-top: 300px;">
        <div class="container">
            <div class="account-wrapper">
                <h3 class="title">Войти</h3>
				<form action="/ozimiz/login.php" method="POST">
                    <div class="form-group">
                        <input type="text" placeholder="Email" name="email">
                    </div>
                    <div class="form-group">
                        <input type="password" placeholder="Пароль" name="password">
                    </div>
                    <div class="form-group">
                        <div class="d-flex justify-content-between flex-wrap pt-sm-2">
                            <div class="checkgroup">
                            </div>
                            <a href="forgetpass.html">Забыли пароль?</a>
                        </div>
                    </div>
                    <div class="form-group text-center">
                        <button class="d-block lab-btn" type="submit" name="do_login">
                            <span>Войти</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Login Section Section Ends Here -->


        <!-- Footer Section Start Here -->
        <footer>
            
            <div class="footer-bottom style-2">
                <div class="container">
                    <div class="section-wrapper">
                        <p>&copy; 2023 <a href="#">Ozimiz</a> Разработана командой<a href="#" target="_blank">Kandichioner</a> </p>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Footer Section Ending Here -->
    </div>
    <!-- footer -->


    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/swiper.min.js"></script>
    <script src="assets/js/progress.js"></script>
    <script src="assets/js/lightcase.js"></script>
    <script src="assets/js/counter-up.js"></script>
    <script src="assets/js/isotope.pkgd.js"></script>
    <script src="assets/js/functions.js"></script>

</body>
</html>
