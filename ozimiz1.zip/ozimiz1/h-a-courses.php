<?php 
	require 'db.php';
?>
<?php
$host = 'localhost';
$dbname = 'ozimiz';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Ошибка подключения к базе данных: " . $e->getMessage());
}

$photos = [
    '/ozimiz/assets/images/6410ebf8e483b53d6186fc53_ABM College Web developer main.jpg',
    '/ozimiz/assets/images/Web-Developer-skill.jpg',
];
$randomPhoto = $photos[array_rand($photos)];
?>


<?php if ( isset ($_SESSION['logged_user']) ) : ?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ozimiz.kaz</title>
    <link rel="shortcut icon" href="assets/images/IMG_7797.PNG" type="image/x-icon">

    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/icofont.min.css">
    <link rel="stylesheet" href="assets/css/swiper.min.css">
    <link rel="stylesheet" href="assets/css/lightcase.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

    <!-- preloader start here -->
    <div class="preloader">
        <div class="preloader-inner">
            <div class="preloader-icon">
                <span></span>
                <span></span>
            </div>
        </div>
    </div>
    <!-- preloader ending here -->


    <!-- scrollToTop start here -->
    <a href="#" class="scrollToTop"><i class="icofont-rounded-up"></i></a>
    <!-- scrollToTop ending here -->


    <!-- header section start here -->
    <header class="header-section">
        <div class="header-bottom">
            <div class="container">
                <div class="header-wrapper">
                    <div class="logo">
                        <a href="#">
                            <img src="assets/images/logo.png"  alt="logo" width="200px">
                        </a>
                    </div>
                    <div class="menu-area">
                        <div class="menu">
                            <ul class="lab-ul">
                                <li>
                                    <a href="/ozimiz/home-admin.php">Главная</a>
                                </li>
                                
                                <li>
                                    <a href="/ozimiz/h-a-courses.php">Курсы</a>
                                </li>
                            </ul>
                        </div>
                        
                        <a href="#" class="login"><i class="icofont-user"></i> <span><?=$_SESSION['logged_user']->name?></span> </a>
                        <a href="/ozimiz/logout.php" class="signup"><i class="icofont-users"></i> <span>Выйти</span> </a>

                        <!-- toggle icons -->
                        <div class="header-bar d-lg-none">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <div class="ellepsis-bar d-lg-none">
                            <i class="icofont-info-square"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- header section ending here -->

    <div  style="padding-top: 100px;padding-bottom: 10px;"> 
       <!-- course section start here -->
    <div class="course-section padding-tb section-bg">
        <div class="container">
            <div class="section-header text-center">
                <span class="subtitle">Курсы</span>
                <h2 class="title">Ваши курсы</h2>
            </div>
            <div class="section-wrapper">
                <div class="row g-4 justify-content-center row-cols-xl-3 row-cols-md-2 row-cols-1">
                <?php
try {
    $stmt = $pdo->query("SELECT * FROM courses");

    // Используйте метод fetch() для получения каждой строки результата
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        
   ?>
                    <div class="col">
                        <div class="course-item">
                            <div class="course-inner">
                                <div class="course-thumb">
                                   <img src="<?=$randomPhoto?>" alt="course">
                                </div>
                                <div class="course-content">
                                    <div class="course-price">$30</div>
                                    <div class="course-category">
                                        <div class="course-cate">
                                            <a href="#"><?=$row['tag']?></a>
                                        </div>
                                        <div class="course-reiew">
                                            <span class="ratting">
                                                <i class="icofont-ui-rating"></i>
                                                <i class="icofont-ui-rating"></i>
                                                <i class="icofont-ui-rating"></i>
                                                <i class="icofont-ui-rating"></i>
                                                <i class="icofont-ui-rating"></i>
                                            </span>
                                            <span class="ratting-count">
                                            <?=$row['long']?> отзыв
                                            </span>
                                        </div>
                                    </div>
                                    <a href="#"><h5><?=$row['name_c']?></h5></a>
                                    <div class="course-details">
                                        <div class="couse-count"><i class="icofont-video-alt"></i> 18x уроков</div>
                                    </div>
                                    <div class="course-footer">
                                        <div class="course-btn">
                                            <a href="#" class="lab-btn-text">Подробнее <i class="icofont-external-link"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                     }
                    } catch (PDOException $e) {
                        echo "Ошибка выполнения запроса: " . $e->getMessage();
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
    <!-- course section ending here -->
    </div>
    <!-- footer -->
    <div class="news-footer-wrap">
        
        <!-- Footer Section Start Here -->
        <footer>
            <div class="footer-bottom style-2">
                <div class="container">
                    <div class="section-wrapper">
                        <p>&copy; 2023 <a href="#">Ozimiz</a> Разработана командой<a href="#" target="_blank">Kandichioner</a> </p>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Footer Section Ending Here -->
    </div>
    <!-- footer -->


    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/swiper.min.js"></script>
    <script src="assets/js/progress.js"></script>
    <script src="assets/js/lightcase.js"></script>
    <script src="assets/js/counter-up.js"></script>
    <script src="assets/js/isotope.pkgd.js"></script>
    <script src="assets/js/functions.js"></script>

</body>
</html>
<?php else : ?>
    <? echo 'none';?>
<?php endif; ?>